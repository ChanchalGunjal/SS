package PreparedStatement_ineterface;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class insert {
public static void main(String[] args)throws Exception {
	Class.forName("com.mysql.cj.jdbc.Driver");
	System.out.println("Driver lod...");
	
	String url="jdbc:mysql://Localhost:3307/b159";
	String username="root";
	String password="root";
	
	Connection con=DriverManager.getConnection(url,username,password);
	PreparedStatement prest=con.prepareStatement("insert into student values(?,?)");
	prest.setInt(1,45);
	prest.setString(2,"Aniket");
	prest.executeUpdate();
	System.out.println("program run...");
	
	
}
}  