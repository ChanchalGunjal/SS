package PreparedStatement_ineterface;

import java.awt.geom.GeneralPath;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Select {
	public static void main(String[] args) throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver lod...");

		String url = "jdbc:mysql://Localhost:3307/b159";
		String username = "root";
		String password = "root";

		Connection con = DriverManager.getConnection(url, username, password);
		PreparedStatement prest = con.prepareStatement("select * from student");
		ResultSet r = prest.executeQuery();

		System.out.println("Id\tName");
		System.out.println("----------------");
		while (r.next()) {
			
			System.out.println(r.getInt(1)+"\t"+r.getString(2));
			

		}
	}
}