package Statement_Interface;


import java.sql.Connection;
import java.sql.DriverManager;

public class insert1 {
    public static void main(String[] args)throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver loading...");
		
		String url="jdbc:mysql://Localhost3307:/b159";
		String username="root";
		String password="root";
		
		Connection con=DriverManager.getConnection(url,username,password);
	    java.sql.Statement st= con.createStatement();
		String queary="insert into studentvalues(108,'sachin')";
		st.execute(queary);
		System.out.println("program sc...");
		
	}
}
