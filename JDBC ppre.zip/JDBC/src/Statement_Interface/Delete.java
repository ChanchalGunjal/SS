package Statement_Interface;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Delete {
	public static void main(String[] args)throws Exception {
		Class .forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver loading...");
		
		
		String url="jdbc:mysql://Localhost:3307/b159";
		String username= "root";
		String password="root";
		
		
		Connection con=DriverManager.getConnection(url,username,password);
		Statement st=con.createStatement();
		String query="Delete from student where id =103";
		
		st.execute(query);
		System.out.println("program run....");
	}
}

