package Statement_Interface;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Insert {
	public static void main(String[] args)throws Exception {
		
   Class.forName("com.mysql.cj.jdbc.Driver");
   System.out.println("Drier loding..");
   
   String url="jdbc:Mysql://Localhost:3307/b159";
   String username="root";
   String password="root";
   
   Connection con=DriverManager.getConnection(url,username,password);
   Statement st=con.createStatement();
   String query="insert into student values(106,'chanchu')";
   
   st.executeUpdate(query);
   
   System.out.println("Program Run Sc");
   
	
	}
	
}
