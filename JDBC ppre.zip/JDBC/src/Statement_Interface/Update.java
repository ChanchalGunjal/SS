package Statement_Interface;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;



public class Update {
	public static void main(String[] args)throws Exception {
		
   Class.forName("com.mysql.cj.jdbc.Driver");
   
   String url="jdbc:Mysql://Localhost:3307/b159";
   String username="root";
   String password="root";
   
   Connection con=DriverManager.getConnection(url,username,password);
   Statement st=con.createStatement();
   String query="update student set name ='manasvi ' where id=2";
   
   st.execute(query);
   
   
   System.out.println("Program Run Sc");
	}
}
